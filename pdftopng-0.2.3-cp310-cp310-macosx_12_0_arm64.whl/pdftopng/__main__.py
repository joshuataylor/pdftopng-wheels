# -*- coding: utf-8 -*-


__all__ = ("main",)


def main():
    from pdftopng.cli import cli

    cli()


if __name__ == "__main__":
    main()
